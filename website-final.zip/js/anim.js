var typed = new Typed('.anim', {
    strings: [
        'Mark Angelo Erna',
        'Jan Rhey Paaño',
        'Yoshiya Ito',
        'Fhill Lewis',
        'Lyla Norella'
    ],
    typeSpeed: 50,
    backSpeed: 50,
    loop: true
});